package gr.hua.dit.ds.rental_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentalManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentalManagementApplication.class, args);
	}

}
